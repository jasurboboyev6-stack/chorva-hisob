# Chorva Hisob — Android boshlang‘ich loyiha

## Hozirgi holat
Bu Android Studio uchun boshlang‘ich Kotlin + Jetpack Compose loyihasi.
Yashil-oq bosh sahifa, chorva guruhlari ro‘yxati, yangi guruh qo‘shish oynasi va oddiy hisobot ko‘rinishi mavjud.

## Android Studio’da ochish
1. Android Studio’ni o‘rnating.
2. `Open` orqali `ChorvaHisob` papkasini tanlang.
3. Gradle sync tugashini kuting.
4. Telefonni USB orqali ulang yoki emulator tanlang.
5. `Run` tugmasini bosing.

## APK yig‘ish
Android Studio menyusi: Build → Build Bundle(s) / APK(s) → Build APK(s).
APK odatda `app/build/outputs/apk/debug/app-debug.apk` ichida yaratiladi.

## Muhim
- Hozirgi loyiha — dastlabki interfeys prototipi.
- Ma’lumotlar hozircha ilova ishlayotgan paytdagi xotirada turadi; ilova yopilganda saqlanib qoladigan Room bazasi hali qo‘shilmagan.
- Firebase login va ko‘p telefonli sinxronlash hali ulanmagan. Buning uchun alohida Firebase loyihasi va `google-services.json` kerak bo‘ladi.
- Savdo, xarajat, nasl, ombor va to‘liq foyda hisoboti keyingi bosqichlarda qo‘shiladi.
