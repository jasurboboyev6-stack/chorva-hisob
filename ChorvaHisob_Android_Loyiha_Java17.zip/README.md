# CHORVA HISOB — Android starter project

Farm: JASUR CHORVACHILIK

## Build requirements
- JDK 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Android SDK 35

The Android module is configured to compile Java and Kotlin for JVM 17.

This is an initial UI prototype. Group data is currently held in memory only; persistent local storage, authentication, cloud synchronization, and the remaining farm modules still need implementation.
