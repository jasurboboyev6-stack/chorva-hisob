package uz.chorvahisob.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green = Color(0xFF176B45)
private val PaleGreen = Color(0xFFEAF5EE)
private val Ink = Color(0xFF17352A)

data class Batch(
    val type: String,
    val group: String,
    val count: Int,
    val purchaseTotal: Long,
    val sold: Int = 0,
    val lost: Int = 0
) {
    val balance: Int get() = (count - sold - lost).coerceAtLeast(0)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ChorvaHisobApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChorvaHisobApp() {
    var selected by remember { mutableStateOf("Bosh sahifa") }
    var batches by remember {
        mutableStateOf(
            listOf(
                Batch("Qo‘y", "Asosiy poda", 50, 25_000_000),
                Batch("Echki", "Ona echkilar", 20, 8_000_000),
                Batch("Qoramol", "Buqalar", 10, 75_000_000),
                Batch("Parranda", "Tovuqlar", 100, 5_000_000)
            )
        )
    }
    var showAdd by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            onPrimary = Color.White,
            secondary = Color(0xFF4B8066),
            background = Color(0xFFF7FAF8),
            surface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Color(0xFFF7FAF8),
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("CHORVA HISOB", fontWeight = FontWeight.ExtraBold, color = Green, letterSpacing = 1.sp)
                            Text("Chorvachilik va savdo boshqaruvi", fontSize = 11.sp, color = Color.Gray)
                        }
                    },
                    actions = {
                        IconButton(onClick = { selected = "Sozlamalar" }) {
                            Icon(Icons.Default.Settings, contentDescription = "Sozlamalar", tint = Green)
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = Color.White)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    val tabs = listOf(
                        "Bosh sahifa" to Icons.Default.Home,
                        "Chorva" to Icons.Default.Pets,
                        "Savdo" to Icons.Default.SwapHoriz,
                        "Hisobot" to Icons.Default.Assessment
                    )
                    tabs.forEach { (label, icon) ->
                        NavigationBarItem(
                            selected = selected == label,
                            onClick = { selected = label },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Green, indicatorColor = PaleGreen, selectedTextColor = Green)
                        )
                    }
                }
            },
            floatingActionButton = {
                if (selected == "Chorva" || selected == "Bosh sahifa") {
                    FloatingActionButton(onClick = { showAdd = true }, containerColor = Green, contentColor = Color.White) {
                        Icon(Icons.Default.Add, contentDescription = "Guruh qo‘shish")
                    }
                }
            }
        ) { padding ->
            when (selected) {
                "Bosh sahifa" -> Dashboard(batches, Modifier.padding(padding), onOpenLivestock = { selected = "Chorva" })
                "Chorva" -> LivestockScreen(batches, Modifier.padding(padding))
                "Savdo" -> SimpleScreen("Savdo", "Xarid va sotuv amallari keyingi bosqichda qo‘shiladi.", Modifier.padding(padding))
                "Hisobot" -> ReportScreen(batches, Modifier.padding(padding))
                else -> SimpleScreen("Sozlamalar", "Foydalanuvchilar, zaxira nusxasi va sinxronlash sozlamalari.", Modifier.padding(padding))
            }
        }

        if (showAdd) {
            AddBatchDialog(
                onDismiss = { showAdd = false },
                onAdd = { batch -> batches = batches + batch; showAdd = false }
            )
        }
    }
}

@Composable
fun Dashboard(batches: List<Batch>, modifier: Modifier = Modifier, onOpenLivestock: () -> Unit) {
    val total = batches.sumOf { it.balance }
    val purchase = batches.sumOf { it.purchaseTotal }
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = Green), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(20.dp)) {
                Text("UMUMIY CHORVA", color = Color.White.copy(alpha = .8f), fontSize = 12.sp)
                Text("$total bosh", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Hisobdagi xarid qiymati: ${money(purchase)} so‘m", color = Color.White, fontSize = 13.sp)
            }
        }
        Text("Asosiy ko‘rsatkichlar", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Ink)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Chorva guruhlari", "${batches.size} ta", "🐑", Modifier.weight(1f))
            MetricCard("Jami bosh soni", "$total ta", "🐄", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Xarid qiymati", money(purchase), "🛒", Modifier.weight(1f))
            MetricCard("Sinxronlash", "Tayyorlanadi", "☁️", Modifier.weight(1f))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Chorva guruhlari", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Ink)
            Spacer(Modifier.weight(1f))
            Text("Barchasi", color = Green, modifier = Modifier.clickable { onOpenLivestock() })
        }
        batches.take(4).forEach { BatchRow(it) }
    }
}

@Composable
fun MetricCard(title: String, value: String, emoji: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(emoji, fontSize = 22.sp)
            Text(value, fontWeight = FontWeight.Bold, color = Green, fontSize = 16.sp)
            Text(title, color = Color.Gray, fontSize = 11.sp)
        }
    }
}

@Composable
fun LivestockScreen(batches: List<Batch>, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Chorva guruhlari", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("Hayvonlar guruh bo‘yicha hisoblanadi", color = Color.Gray, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(batches) { BatchRow(it) }
        }
    }
}

@Composable
fun BatchRow(batch: Batch) {
    val emoji = when (batch.type) { "Qo‘y" -> "🐑"; "Echki" -> "🐐"; "Qoramol" -> "🐄"; else -> "🐓" }
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).background(PaleGreen, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                Text(emoji, fontSize = 25.sp)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(batch.group, fontWeight = FontWeight.Bold, color = Ink)
                Text("${batch.type} • Kirim: ${batch.count} ta", color = Color.Gray, fontSize = 12.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("${batch.balance} ta", fontWeight = FontWeight.Bold, color = Green)
                Text("Qoldiq", color = Color.Gray, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun ReportScreen(batches: List<Batch>, modifier: Modifier = Modifier) {
    val total = batches.sumOf { it.balance }
    val value = batches.sumOf { it.purchaseTotal }
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Hisobotlar", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
        MetricCard("Jami chorva qoldig‘i", "$total bosh", "📊", Modifier.fillMaxWidth())
        MetricCard("Jami xarid qiymati", "${money(value)} so‘m", "💰", Modifier.fillMaxWidth())
        Text("Tafsilotlar", fontWeight = FontWeight.Bold, color = Ink)
        batches.forEach { BatchRow(it) }
        Text("Sof foyda savdo va xarajatlar modullari kiritilgach hisoblanadi.", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun SimpleScreen(title: String, description: String, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text(description, color = Color.Gray)
    }
}

@Composable
fun AddBatchDialog(onDismiss: () -> Unit, onAdd: (Batch) -> Unit) {
    var type by remember { mutableStateOf("Qo‘y") }
    var group by remember { mutableStateOf("") }
    var count by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    val types = listOf("Qo‘y", "Echki", "Qoramol", "Parranda")
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Chorva guruhini qo‘shish", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Box {
                    OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Chorva turi: $type")
                    }
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        types.forEach { item -> DropdownMenuItem(text = { Text(item) }, onClick = { type = item; expanded = false }) }
                    }
                }
                OutlinedTextField(group, { group = it }, label = { Text("Guruh nomi") }, singleLine = true)
                OutlinedTextField(count, { count = it.filter(Char::isDigit) }, label = { Text("Soni") }, singleLine = true)
                OutlinedTextField(price, { price = it.filter(Char::isDigit) }, label = { Text("Jami xarid qiymati (so‘m)") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val n = count.toIntOrNull()
                val p = price.toLongOrNull()
                if (group.isNotBlank() && n != null && n > 0 && p != null && p >= 0) {
                    onAdd(Batch(type, group.trim(), n, p))
                }
            }) { Text("Saqlash", color = Green) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } }
    )
}

fun money(value: Long): String = "%,d".format(value).replace(',', ' ')
